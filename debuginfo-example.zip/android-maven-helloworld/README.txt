- Import into Eclipse: File/Import/Maven/Existing Maven Projects

- Eclipse configuration:
   - Eclipse 4.3 (Kepler)
   - Java or JavaEE package
   - ADT Android Development Tools plugin
      - web: http://developer.android.com/sdk/installing/installing-adt.html
      - update site: https://dl-ssl.google.com/android/eclipse/
   - m2e-android configurator
      - web: http://rgladwell.github.io/m2e-android/

- Maven 3.1.1 or higher
   - web: http://maven.apache.org/download.cgi
   - setup Eclipse to use this external installation
      (Window/Preferences/Maven/Installations/Add)
   - Windows environment variable: M2_HOME C:\Maven
   - Windows Path: %M2_HOME%\bin;

- Android SDK 22.3.0 or higher
   - web: http://developer.android.com/sdk/index.html (zip: click "Download 
      for other platforms")
   - run SDK Manager, do full installation (all older devices, sources, 
      extras, etc.)
   - Windows environment variable: ANDROID_HOME C:\android-sdk-windows
   - Windows Path:
     %ANDROID_HOME%\tools;%ANDROID_HOME%\tools\lib;%ANDROID_HOME%\platform-tools;
   - setup Eclipse to use this external installation
      (Window/Preferences/Android/SDK Location)
   - Export all jar-s to Maven repository by:
      https://github.com/mosabua/maven-android-sdk-deployer
