- Replace res/ folder to decompiled one, copy decompiled assets/ too (if exists)
- Copy decompiled AndroidManifest.xml, always check and complete <uses-sdk> tag:
    <uses-sdk
        android:minSdkVersion="8"
        android:targetSdkVersion="16" />

- Place decompiled jar to project root directory /debugable-classes-dex2jar.jar
- Install it to the local Maven repository by running install-jar.bat

- Import project into Eclipse, or run 
    Maven/Update Project on it if already imported
- Find decompiled classes in Eclipse under 
    Maven Dependencies/debugable-classes-1.0.0.jar
